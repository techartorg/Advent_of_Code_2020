// Copyright Epic Games, Inc. All Rights Reserved.

#include "AdventOfCode2020.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, AdventOfCode2020, "AdventOfCode2020" );
